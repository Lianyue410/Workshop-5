const fs = require('fs');

const raw = fs.readFileSync('customers.json', 'utf8');
const customers = JSON.parse(raw);

const medicationByVolume = customers.map(c => ({
  medication: c.medication,
  volume: c.volume,
  generalLocation: `${c.city}, ${c.county}`
}));

fs.writeFileSync('medicationbyvolume.json', JSON.stringify(medicationByVolume, null, 2));

console.log('Done. Records:', medicationByVolume.length);